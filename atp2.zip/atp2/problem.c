#include <stdio.h>

int main(void)
{
    printf("Enter floor: ");
    int N;
    scanf("%i", &N);
    int floors[N];
    printf("Enter amount of people: ");
    int M;
    scanf("%i", &M);
    floors[0] = M;

    int result = 0;
    for (int i = 1; i < N; i++)
    {
        floors[i] = floors[i - 1] + 4;
        result = result + floors[i];
    }
    printf("%i\n", result);
}
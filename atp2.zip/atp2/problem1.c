#include <stdio.h>

int main()
{
    printf("Array size: ");
    int n;
    scanf("%i", &n);
    int array[n];

    for (int i = 0; i < n; i++)
    {
        printf("Enter %i-th element of array: ", i);
        scanf("%i", &array[i]);
    }

    int min = array[0];
    int min_ind = 0;
    int max = array[0];
    int max_ind = 0;

    for (int i = 0; i < n; i++)
    {
        if (min < array[i])
        {
            min = array[i];
            min_ind = i;
        }

        if (max > array[i])
        {
            max = array[i];
            max_ind = i;
        }
    }

    int save = array[max_ind];
    array[max_ind] = array[min_ind];
    array[min_ind] = save;

    for (int i = 0; i < n; i++)
    {
        printf("%i-th element of array: %i\n", i, array[i]);
    }
}